# Paired task orchestration — outcome-based revision

**Delivery:** revised source files and an unapplied patch, derived from the complete canonical `.agents/skills/paired-task-orchestration/` package in Custom Skills Workbench. No project file or task was edited. No regular custom skill was revised.

## Substantive changes

- Routine programming within approved boundaries is explicitly delegated. Unspecified equivalent method choices need no separate approval, per-choice record, step-by-step narration, exhaustive method checklist, or routine method-change ledger.
- Primary plans specify outcomes, scope, acceptance evidence, permissions, limits, and material escalation triggers. The verifier checks every applicable approved obligation independently, not the author's coding decisions.
- The optional record-layout example is clearly non-normative. The hook reservation/CAS example allows equivalent verified coordination without weakening exclusion, version, conflict, idempotency, or finite-execution requirements.
- Authoring-only definition revision is distinguished from installation and series initialization. It grants no checks, task creation, publication, feature implementation, or enforcement.
- The existing document-contract test source gains outcome/autonomy/exception assertions and tolerates harmless wrapping in its existing authority checks. Its six staging safeguards remain unchanged. Assertions cover contract boundaries, not every illustrative method.

## Retained controls

Authorized pairing, piece order, actual dependencies, full payload/readback, draft-versus-execution separation, duplicate and uncertain-write reconciliation, reviewer-local delivery readiness, independent verification, gap-before-repair reporting, scoped repairs, evidence invalidation and independent post-repair acceptance all remain required.

Exceptions, waivers, changes to acceptance/coverage, and material changes to scope, authority, execution permissions, limits, safety, privacy, compatibility, data integrity, ownership, recovery, and completion retain their applicable escalation routes. Fixed methods genuinely required by a contract remain fixed. Actual protected-plan or executable-payload changes still require authorized amendment, bindings and readback.

Required approval, execution, incident, provenance, consumption and acceptance evidence remains mandatory. Expected negative/non-zero outcomes, source/bootstrap/runtime distinctions, canonical-source restrictions and hook/automatic-progression limits are unchanged.

## Material contract changes

The new explicit delegation rule and equivalent-coordination allowance change prospective instructional behavior. They do not waive acceptance criteria or execution restrictions. The authorization is the user's attached revision request, narrowed to paired task orchestration.

The Router's existing delivery-reconciliation policy still requires logged resolution/correction when a specified verification method or protected executable payload actually changes. This revision does not amend that separate skill. Choosing an unspecified equivalent coding method within an unchanged plan is different from rewriting that plan.

## Inspection and execution status

Read the complete canonical entry point and all three Paired references, the applicable canonical Router entry point and verification/binding/delivery references, and the confirmation companion. Inspected relevant existing document-contract source and current task records. This was source and record inspection, not executable validation.

**NOT_RUN:** tests, guards, imports, syntax checks, builds, package commands, runtime/store operations, CI and enforcement. The edited test source was authored but never executed. No passing-test, independent-acceptance, installation, publication, runtime-activation or merge claim is made.

## Existing plans and binding limitations

Fresh records showed #149, #150 and #151 as Ready. Their full plans were inspected; no running instructions, historical approvals, accepted results, native dependencies or lifecycle states were rewritten. These labels do not establish acceptance. #149 expressly excludes canonical skill editing; this separate source revision does not broaden that task.

The named Failure Gate plan, retrospective confirmation, historical package manifests and reports stay unchanged. Applying the revised package later changes all four Paired source bindings: old digests/acceptance cannot certify the new bytes. The existing current-handoff digest-checking test remains unchanged so it continues to detect stale bindings; it was not weakened or run. Any required plan amendment or evidence renewal must use its supported authorized route and preserve history. This delivery does not create such a task or grant that operation.

The source retains its narrowly conditioned temporary planner-staging exception. The current user's absolute prohibition on writing deliverables under `.local/` takes precedence; no `.local/` file was written.

## Package contents

- The revised canonical-relative `SKILL.md` and all three supporting references.
- Revised `scripts/test/paired-planner-staging-source.test.mjs`.
- An unapplied `revision.patch` and this report.
- Baseline/revised byte counts and content digests in `source-bindings.json`;
  these identify authored inputs and outputs, not a passing validation run.

The downloadable package is an authoring deliverable, not an installed canonical source or workspace publication. Project application and independent acceptance remain unperformed.
